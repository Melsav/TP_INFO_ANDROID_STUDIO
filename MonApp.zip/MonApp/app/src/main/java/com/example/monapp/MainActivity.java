package com.example.monapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.database.Cursor;
import android.app.AlertDialog.Builder;


public class MainActivity extends AppCompatActivity {

    private Button buttonvalider;
    private EditText pseudo1, password1, ConfPassword;
    private Spinner spinnerassoc;

    // BDD

    ResultSet rst = null;
    public static  Connection con = null;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        StrictMode.setThreadPolicy(new
                StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .penaltyLog()
                .penaltyDeath()
                .build());



        buttonvalider = (Button) findViewById(R.id.buttonvalider);
        pseudo1 = (EditText) findViewById(R.id.pseudo1);
        password1 = (EditText) findViewById(R.id.password1);
        ConfPassword = (EditText) findViewById(R.id.ConfPassword);
        spinnerassoc = (Spinner) findViewById(R.id.spinnerassoc);

        MysqlConnexion();

        SpinnerAssoc();


        // Traitement boutton Valider + enregistrement des données user

        buttonvalider.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {



                if (password1.getText().toString().equals(ConfPassword.getText().toString())) {

                    Toast.makeText(MainActivity.this, "Confirmation du mot de passe valide" , Toast.LENGTH_LONG).show();




                    try {

                        String sqlval1 = "insert into user (id, username,password) values (NULL, ?,?) ";
                        PreparedStatement pstmval1 = con.prepareStatement(sqlval1);
                        pstmval1.setString(1, pseudo1.getText().toString());
                        pstmval1.setString(2, password1.getText().toString());
                        pstmval1.executeUpdate();
                        CleanText();

                    } catch (SQLException seinst) {
                        Toast.makeText(MainActivity.this, "liste." + seinst.toString(), Toast.LENGTH_LONG).show();
                        Log.d("MainActivity", seinst.getMessage());


                    }

                    Intent otherslide = new Intent(getApplicationContext(), activitynumber2.class);
                    startActivity(otherslide);


                } else {
                    Toast.makeText(MainActivity.this, "Veuiller vérifier votre mot de passe" , Toast.LENGTH_LONG).show();
                }
            }

        });

    }

    // Connexion BDD

    private void MysqlConnexion() {


        String jdbcURL="jdbc:mysql://10.4.253.25:3306/association";
        String username = "username";
        String password = "password";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, username, password);


        } catch ( ClassNotFoundException e) {
            Toast.makeText(MainActivity.this, "Drive manquant." +e.getMessage().toString(), Toast.LENGTH_LONG).show();
        } catch ( java.sql.SQLException ex ) {
            Toast.makeText(MainActivity.this, "Connexion au serveur impossible." +ex.getMessage().toString(), Toast.LENGTH_LONG).show();
            Log.d("error", "SQLException: " + ex.getMessage());
            Log.d("error", "SQLState: " + ex.getSQLState());
            Log.d("error", "VendorError: " + ex.getErrorCode());
        }

         Toast.makeText(this," La connexion à la base de donnée est établie avec succès ", Toast.LENGTH_LONG).show();


    }

    public void CleanText() {

        pseudo1.setText("");
        password1.setText("");
        password1.requestFocus();



    }


   // void pour récupérer les données BDD et les afficher dans le spinner


    public void SpinnerAssoc() {
        try {
            String req = "SELECT Name FROM assocs";
            Statement pstm = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            ResultSet rst = pstm.executeQuery(req);
            List<String> list = new ArrayList<>();

            while (rst.next()) {
                list.add(rst.getString(1));
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerassoc.setAdapter(adapter);
        } catch (SQLException se) {
            se.printStackTrace();
        }
    }


}