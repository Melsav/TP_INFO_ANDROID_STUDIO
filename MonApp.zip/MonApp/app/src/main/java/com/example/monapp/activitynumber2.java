package com.example.monapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.StrictMode;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.app.AlertDialog.Builder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class activitynumber2 extends AppCompatActivity  {


    private Button buttonvisu1,  buttonvisu3;
    private EditText wanted;

    ResultSet rstx = null;
    public static Connection conx = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activitynumber2);
        Log.d("My app", "2nd slide");


        StrictMode.setThreadPolicy(new
                StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .penaltyLog()
                .penaltyDeath()
                .build());


        MysqlConnexion();


        this.buttonvisu1 = (Button) findViewById(R.id.buttonvisu1);
        this.buttonvisu3 = (Button) findViewById(R.id.buttonvisu3);
        this.wanted = (EditText) findViewById(R.id.wanted);


        buttonvisu3.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent otherslide2 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(otherslide2);
            }


        });


        buttonvisu1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

           try {
               String sqlshow = "select name from assocs " ;
               Statement pstmx = conx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
               rstx = pstmx.executeQuery(sqlshow);

               while (rstx.next()){
                   wanted.setText(rstx.getString(1));
                   wanted.setText(rstx.getString(2));
                   wanted.setText(rstx.getString(3));
               }



           } catch (SQLException se) {


               Log.d("activitynumber2", se.getMessage());

           }



            }


        });

    }

    private void MysqlConnexion() {


        String jdbcURL = "jdbc:mysql://10.4.253.25:3306/association";
        String username = "username";
        String password =  "password";
        try {
            Class.forName("com.mysql.jdbc.Driver");
           conx = DriverManager.getConnection(jdbcURL, username, password);


        } catch (ClassNotFoundException e) {
            Toast.makeText(activitynumber2.this, "Drive manquant." + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        } catch (java.sql.SQLException ex) {
            Toast.makeText(activitynumber2.this, "Connexion au serveur impossible." + ex.getMessage().toString(), Toast.LENGTH_LONG).show();
            Log.d("error", "SQLException: " + ex.getMessage());
            Log.d("error", "SQLState: " + ex.getSQLState());
            Log.d("error", "VendorError: " + ex.getErrorCode());
        }

        Toast.makeText(this, " La connexion à la base de donnée est établie avec succès ", Toast.LENGTH_LONG).show();


    }


}